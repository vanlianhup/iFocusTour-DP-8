<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'dao', 'diao', 'dao', 'ren', 'ren', 'chuang', 'fen', 'qie', 'yi', 'ji', 'kan', 'qian', 'cun', 'chu', 'wen', 'ji',
  0x10 => 'dan', 'xing', 'hua', 'wan', 'jue', 'li', 'yue', 'lie', 'liu', 'ze', 'gang', 'chuang', 'fu', 'chu', 'qu', 'ju',
  0x20 => 'shan', 'min', 'ling', 'zhong', 'pan', 'bie', 'jie', 'jie', 'pao', 'li', 'shan', 'bie', 'chan', 'jing', 'gua', 'geng',
  0x30 => 'dao', 'chuang', 'kui', 'ku', 'duo', 'er', 'zhi', 'shua', 'quan', 'sha', 'ci', 'ke', 'jie', 'gui', 'ci', 'gui',
  0x40 => 'kai', 'duo', 'ji', 'ti', 'jing', 'lou', 'luo', 'ze', 'yuan', 'cuo', 'xue', 'ke', 'la', 'qian', 'sha', 'chuang',
  0x50 => 'gua', 'jian', 'cuo', 'li', 'ti', 'fei', 'pou', 'chan', 'qi', 'chuang', 'zi', 'gang', 'wan', 'bo', 'ji', 'duo',
  0x60 => 'qing', 'shan', 'du', 'jian', 'ji', 'bo', 'yan', 'ju', 'huo', 'sheng', 'jian', 'duo', 'duan', 'wu', 'gua', 'fu',
  0x70 => 'sheng', 'jian', 'ge', 'da', 'kai', 'chuang', 'chuan', 'chan', 'tuan', 'lu', 'li', 'peng', 'shan', 'piao', 'kou', 'jiao',
  0x80 => 'gua', 'qiao', 'jue', 'hua', 'zha', 'zhuo', 'lian', 'ju', 'pi', 'liu', 'gui', 'jiao', 'gui', 'jian', 'jian', 'tang',
  0x90 => 'huo', 'ji', 'jian', 'yi', 'jian', 'zhi', 'chan', 'jian', 'mo', 'li', 'zhu', 'li', 'ya', 'quan', 'ban', 'gong',
  0xA0 => 'jia', 'wu', 'mai', 'lie', 'jin', 'keng', 'xie', 'zhi', 'dong', 'zhu', 'nu', 'jie', 'qu', 'shao', 'yi', 'zhu',
  0xB0 => 'mo', 'li', 'jin', 'lao', 'lao', 'juan', 'kou', 'yang', 'wa', 'xiao', 'mou', 'kuang', 'jie', 'lie', 'he', 'shi',
  0xC0 => 'ke', 'jin', 'gao', 'bo', 'min', 'chi', 'lang', 'yong', 'yong', 'mian', 'ke', 'xun', 'juan', 'qing', 'lu', 'bu',
  0xD0 => 'meng', 'chi', 'lei', 'kai', 'mian', 'dong', 'xu', 'xu', 'kan', 'wu', 'yi', 'xun', 'weng', 'sheng', 'lao', 'mu',
  0xE0 => 'lu', 'piao', 'shi', 'ji', 'qin', 'jiang', 'chao', 'quan', 'xiang', 'yi', 'jue', 'fan', 'juan', 'tong', 'ju', 'dan',
  0xF0 => 'xie', 'mai', 'xun', 'xun', 'lu', 'li', 'che', 'rang', 'quan', 'bao', 'shao', 'yun', 'jiu', 'bao', 'gou', 'wu',
];
